package com.email.Service;

import java.net.PasswordAuthentication;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

@Service
public class service {
	public boolean sendEmail(String subject, String message, String to) {
		// Variable for gmail
		boolean flag = false;
		String from = "amansingh09977@gmail.com";
		String host = "smtp.gmail.com";

		// Get the system properties
		Properties properties = System.getProperties();
		System.out.println(properties);

		// Setting important information to properties object

		// host set
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", "465");
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");

		// Steps to get session object

		// Step 1:
		Session session = Session.getInstance(properties, new Authenticator() {

			@Override
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {

				return new javax.mail.PasswordAuthentication("amansingh09977@gmail.com", "phuz qyoy uhgv dmna");
			}

		});
		session.setDebug(true);

		// Steps 2: Compose the message [text, multimedia message ] by using mime
		// message

		MimeMessage mimeMessage = new MimeMessage(session);

		try {
			// from email
			mimeMessage.setFrom(from);
			// adding recipient to message
			mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			// adding subject to message
			mimeMessage.setSubject(subject);
			// adding text message
			mimeMessage.setText(message);

			// Step 3: Now we can send the message using transport class
			Transport.send(mimeMessage);

			System.out.println("Message Sent Successfully");
			flag = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
